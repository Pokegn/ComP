#pragma once

#include <ctime>
#include <cstdlib>

class CDado{

    public:

        CDado();
        int roll();

};



