(TAREA 3)

Para compilar el programa, se usa la siguiente línea

g++ -o snakes3 snakes.cpp CDado.cpp

ó se puede correr el archivo adjunto snakes3.exe

